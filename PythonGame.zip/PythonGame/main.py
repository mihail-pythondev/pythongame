import random
import time
import pygame
from random import randint
from os import path
from threading import Thread

img_dir = path.join(path.dirname(__file__), "img")
snd_dir = path.join(path.dirname(__file__), "snd")

FPS = 30
score = 0

WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
YELLOW = (255, 255, 0)
BLUE = (0, 0, 255)

# включаем Пайгейм и создаем окно
pygame.init()
pygame.mixer.init()
info = pygame.display.Info()
width = info.current_w
height = info.current_h
WIDTH = width
HEIGHT = height - 50
screen = pygame.display.set_mode((0, 0), pygame.FULLSCREEN)
pygame.display.set_caption("Space Invaders") # Устанавливаем название для игры
clock = pygame.time.Clock()

CENTER_X = (screen.get_width()//2)
CENTER_Y = (screen.get_height()//2)
print(CENTER_X, CENTER_Y)

# Функции для текста и отображения переменных
def draw_shield_bar(surf, x, y, pct, color):
    if pct < 0:
        pct = 0
    BAR_LENGTH = 500
    BAR_HEIGHT = 50
    fill = (pct / 100) * BAR_LENGTH
    outlane_rect = pygame.Rect(x, y, BAR_LENGTH, BAR_HEIGHT)
    fill_rect = pygame.Rect(x, y, fill, BAR_HEIGHT)
    pygame.draw.rect(surf, color, fill_rect)
    pygame.draw.rect(surf, WHITE, outlane_rect, 2)

def draw_energy_bar(surf, x, y, pct, color):
    if pct < 0:
        pct = 0
    BAR_LENGTH = 500
    BAR_HEIGHT = 50
    fill = (pct / 100) * BAR_LENGTH
    outlane_rect = pygame.Rect(x, y, BAR_LENGTH, BAR_HEIGHT)
    fill_rect = pygame.Rect(x, y, fill, BAR_HEIGHT)
    pygame.draw.rect(surf, color, fill_rect)
    pygame.draw.rect(surf, WHITE, outlane_rect, 2)

def draw_ammo_bar(surf, x, y, pct, color):
    if pct < 0:
        pct = 0
    BAR_LENGTH = 500
    BAR_HEIGHT = 50
    fill = (pct / 30) * BAR_LENGTH
    outlane_rect = pygame.Rect(x, y, BAR_LENGTH, BAR_HEIGHT)
    fill_rect = pygame.Rect(x, y, fill, BAR_HEIGHT)
    pygame.draw.rect(surf, color, fill_rect)
    pygame.draw.rect(surf, WHITE, outlane_rect, 2)

def draw_text(surf=screen, text='text', size=36, x=0, y=0, color=WHITE):
    font = pygame.font.Font(pygame.font.match_font("arial"), size)
    text_surface = font.render(text, True, color)
    text_rect = text_surface.get_rect()
    text_rect.midtop = (x, y)
    surf.blit(text_surface, text_rect)

# Выбор режима
while True:
    # Устанавливаем значение ФПС
    clock.tick(FPS)
    # Проверка нажал ли игрок на крестик
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
            break
    key = pygame.key.get_pressed()
    if key[pygame.K_0]:
        HARDMODE = 0
        break
    if key[pygame.K_1]:
        HARDMODE = 1
        break
    if key[pygame.K_2]:
        HARDMODE = 2
        break
    if key[pygame.K_3]:
        HARDMODE = 3
        break
    if key[pygame.K_4]:
        HARDMODE = 10
        break
    screen.fill(BLACK)
    draw_text(x=CENTER_X, y=CENTER_Y-90, text="Выберите уровень сложности - 0, 1, 2 или 3", size=30)
    draw_text(x=CENTER_X, y=CENTER_Y, text="Клавиша [1] - Легкий", size=25)
    draw_text(x=CENTER_X, y=CENTER_Y+30, text="Клавиша [2] - Средний", size=25)
    draw_text(x=CENTER_X, y=CENTER_Y+60, text="Клавиша [3] - Сложный", size=25)
    draw_text(x=CENTER_X, y=CENTER_Y+90, text="Клавиша [0] - Тестовый", size=25)

    # ПОСЛЕ отрисовки всего, переворачиваем экран
    pygame.display.flip()


# Класс для пуль
class Bullet(pygame.sprite.Sprite):
    def __init__(self, x, y, size=(13, 55)):
        pygame.sprite.Sprite.__init__(self)
        self.image = bullet_img
        self.size = size
        self.image = pygame.transform.scale(bullet_img, size)
        self.image.set_colorkey(BLACK)
        self.rect = self.image.get_rect()
        self.rect.bottom = y
        self.rect.centerx = x
        self.speedy = -10

    def update(self):
        self.rect.y += self.speedy
        # Убиваем спрайт если он достиг края экрана
        if self.size == (13, 55):
            if self.rect.bottom < 0:
                self.kill()
        else:
            if self.rect.y < -3000:
                self.kill()


# Создаем класс отвечающий за персонажа
class Player(pygame.sprite.Sprite):
    def __init__(self):
        pygame.sprite.Sprite.__init__(self)
        global HARDMODE
        self.image = player_img
        self.image.set_colorkey(BLACK)
        self.rect = self.image.get_rect()
        self.rect.centerx = WIDTH // 2
        self.rect.bottom = HEIGHT - 10
        self.speedx = 0
        self.speedy = 0
        self.timer = 0
        self.ttimer = 0
        self.bullets = 10
        self.hp = 100
        self.energy = 60
        self.speedboost = 0
        if HARDMODE == 1: self.hp = 100
        elif HARDMODE == 2: self.hp = 75
        elif HARDMODE == 3: self.hp = 50
        elif HARDMODE == 4: self.hp = 1

    def update(self):
        self.speedx = 0
        if self.energy > 100:
            self.energy = 100
        if self.bullets > 30:
            self.bullets = 30
        self.speedy = 0
        self.ttimer += 1
        self.energy += 0.1
        keystate = pygame.key.get_pressed()
        if keystate[pygame.K_SPACE]:
            if self.ttimer % 10 == 0 and self.bullets > 0:
                if self.energy < 80:
                    self.shoot()
                    shoot_sound.play()
                    self.bullets -= 1
                else:
                    self.shoot(size=(400, 1200))
                    shoot_sound.play()
                    self.bullets -= 1
                    self.energy -= 80
        if keystate[pygame.K_a]:  # Управление на стрелочках
            self.speedx = -5  # Скорость передвижения
        if keystate[pygame.K_d]:  # Управление на стрелочках
            self.speedx = 5  # Скорость передвижения
        if keystate[pygame.K_w]:
            self.speedy = -5
        if keystate[pygame.K_s]:
            self.speedy = 5
        if keystate[pygame.K_ESCAPE]:
            global running
            running = False
        if keystate[pygame.K_LSHIFT]:
            if self.speedx == 5:
                self.speedx = 7.5
            elif self.speedx == -5:
                self.speedx = -7.5
            if self.speedy == 5:
                self.speedy = 7.5
            elif self.speedy == -5:
                self.speedy = -7.5
        else:
            if self.speedx == 7.5:
                self.speedx = 5
            elif self.speedx == -7.5:
                self.speedx = -5
            if self.speedy == 7.5:
                self.speedy = 5
            elif self.speedy == -7.5:
                self.speedy = -5
        if self.speedx == 5:
            self.speedx += self.speedboost
        elif self.speedx == -5:
            self.speedx -= self.speedboost
        if self.speedy == 5:
            self.speedy += self.speedboost
        elif self.speedy == -5:
            self.speedy -= self.speedboost
        self.rect.x += self.speedx
        self.rect.y += self.speedy
        if self.rect.right > WIDTH:
            self.rect.right = WIDTH
        if self.rect.left < 0:
            self.rect.left = 0
        if self.rect.y < 0:
            self.rect.y = 0
        if self.rect.y > HEIGHT - 50:
            self.rect.y = HEIGHT - 50
    def shoot(self, size="standart"):
        if size == "standart":
            bullet = Bullet(self.rect.centerx, self.rect.top)
            all_sprites.add(bullet)
            bullets.add(bullet)
        else:
            bullet = Bullet(self.rect.centerx, self.rect.top, size)
            all_sprites.add(bullet)
            superbullets.add(bullet)

running = True

# Класс для бустов
class Boost(pygame.sprite.Sprite):
    def __init__(self, target):
        pygame.sprite.Sprite.__init__(self)
        self.type = randint(1, 3)
        if self.type == 1: self.image = health_img
        elif self.type == 2: self.image = speed_img
        else: self.image = energy_img
        self.image.set_colorkey(BLACK)
        self.target = target
        self.rect = self.image.get_rect()
        self.rect.centerx = randint(0, 100)
        self.rect.bottom = randint(0, 100)
        self.speedx = 0
        self.speedy = 0
        self.rect.x = randint(0, WIDTH)
        self.rect.y = randint(0, HEIGHT)
        self.a = 0
    def update(self):
        self.rect.x += self.speedx
        self.rect.y += self.speedy
        self.speedx = 0
        self.speedy = 0
        if self.rect.x > self.target.rect.x:
            self.speedx = float(randint(1, 10) // 10)
        if self.rect.x < self.target.rect.x:
            self.speedx = float(randint(-10, -1) // 10)
        if self.rect.y < self.target.rect.y:
            self.speedy = float(randint(-10, -1) // 10)
        if self.rect.y > self.target.rect.y:
            self.speedy = float(randint(1, 10) // 10)
        if self.rect.right > WIDTH:
            self.rect.right = WIDTH
        if self.rect.left < 0:
            self.rect.left = 0
        if self.rect.y < 0:
            self.rect.y = 0
        if self.rect.y > 560:
            self.rect.y = 560
        if self.rect.colliderect(self.target.rect):
            t = self.type
            if t == 1:
                self.kill()
                boost_sound.play()
                if self.target.hp > 74:
                    self.target.hp = 100
                else:
                    self.target.hp += 25
            elif t == 2:
                self.kill()
                speed_sound.play()
                self.target.speedboost += 5
                Thread(target=deleteSpeedBoost).start()
            else:
                self.kill()
                boost_sound.play()
                if self.target.energy > 74:
                    self.target.energy = 100
                else:
                    self.target.energy += 25
def deleteSpeedBoost():
    for i in range(5):
        time.sleep(1)
        player.speedboost -= 1

# Классы мобов
class Mob(pygame.sprite.Sprite):
    def __init__(self, target):
        pygame.sprite.Sprite.__init__(self)
        self.sprite = random.choice(meteor_image)
        self.image = self.sprite
        self.image = pygame.transform.scale(self.image, (self.sprite.get_width() * 2, self.sprite.get_height() * 2))
        self.type = "lg"
        self.image.set_colorkey(BLACK)
        self.rect = self.image.get_rect()
        self.rect.centerx = WIDTH // 2
        self.rect.bottom = HEIGHT - 500
        self.speedx = randint(-5, 5)
        self.speedy = randint(-5, 5)
        self.a = 0
        self.target = target
        self.rect.x = CENTER_X
        self.rect.y = CENTER_Y - 200

    def update(self):
        self.rect.x += self.speedx
        self.rect.y += self.speedy
        self.a += 1
        if self.rect.right > WIDTH:
            self.rect.right = WIDTH
            self.speedx = randint(-5, -1)
        if self.rect.left < 0:
            self.rect.left = 0
            self.speedx = randint(1, 5)
        if self.rect.y < 0:
            self.rect.y = 0
            self.speedy = randint(1, 5)
        if self.rect.y > 560:
            self.rect.y = 560
            self.speedy = randint(-5, -1)
        if self.a > 59:
            self.a = 0
            self.speedx = randint(-5, 5)
            self.speedy = randint(-5, 5)
        if self.rect.colliderect(self.target):
            global running
            player.hp -= 25
            self.kill()
            if player.hp <= 0:
                running = False
                lose()

class Mob2(pygame.sprite.Sprite):
    def __init__(self, target):
        pygame.sprite.Sprite.__init__(self)
        self.image = enemy_img
        self.image.set_colorkey(BLACK)
        self.type = "sm"
        self.target = target
        self.rect = self.image.get_rect()
        self.rect.centerx = randint(0, 100)
        self.rect.bottom = randint(0, 100)
        self.speedx = 0
        self.speedy = 0
        self.rect.x = CENTER_X
        self.rect.y = CENTER_Y - 400

    def update(self):
        self.rect.x += self.speedx
        self.rect.y += self.speedy
        self.speedx = 0
        self.speedy = 0
        if self.rect.x > self.target.rect.x:
            self.speedx = randint(-3, -1)
        if self.rect.x < self.target.rect.x:
            self.speedx = randint(1, 3)
        if self.rect.y < self.target.rect.y:
            self.speedy = randint(1, 3)
        if self.rect.y > self.target.rect.y:
            self.speedy = randint(-3, -1)
        if self.rect.colliderect(self.target):
            global running
            player.hp -= 25
            self.kill()
            if player.hp <= 0:
                running = False
                lose()

# Класс для взрывов
class Explosion(pygame.sprite.Sprite):
    def __init__(self, center, size):
        pygame.sprite.Sprite.__init__(self)
        self.size = size
        self.image = explosion_anim[self.size][0]
        self.rect = self.image.get_rect()
        self.rect.center = center
        self.frame = 0
        self.last_update = pygame.time.get_ticks()
        self.frame_rate = 50
    def update(self):
        now = pygame.time.get_ticks()
        if now - self.last_update > self.frame_rate:
            self.last_update = now
            self.frame += 1
            if self.frame == len(explosion_anim[self.size]):
                self.kill()
            else:
                center = self.rect.center
                self.image = explosion_anim[self.size][self.frame]
                self.rect = self.image.get_rect()
                self.rect.center = center

# Загрузка всей игровой графики
explosion_anim = {'lg': [], "sm": []}
for i in range(9):
    filename = f"sonicExplosion0{i}.png".format()
    img = pygame.image.load(path.join(img_dir, filename)).convert()
    img.set_colorkey(BLACK)
    img_lg = pygame.transform.scale(img, (75, 75))
    explosion_anim["lg"].append(img_lg)
    img_sm = pygame.transform.scale(img, (32, 32))
    explosion_anim["sm"].append(img_sm)

meteor_image = []
meteor_list = ["meteorBrown_big1.png", "meteorBrown_big2.png", "meteorBrown_big3.png",
               "meteorBrown_big4.png", "meteorBrown_med1.png",
               "meteorBrown_med3.png", "meteorBrown_small1.png", "meteorBrown_small2.png",
               "meteorBrown_tiny1.png", "meteorBrown_tiny2.png",
               "meteorGrey_big1.png", "meteorGrey_big2.png", "meteorGrey_big3.png",
               "meteorGrey_big4.png", "meteorGrey_med1.png",
               "meteorGrey_med2.png", "meteorGrey_small1.png", "meteorGrey_small2.png",
               "meteorGrey_tiny1.png", "meteorGrey_tiny2.png"]
for img in meteor_list:
    meteor_image.append(pygame.image.load(path.join(img_dir, img)).convert())

background = pygame.image.load(path.join(img_dir, "darkPurple.png")).convert()
background = pygame.transform.scale(background, (1920, 1080))
background_rect = background.get_rect()
player_img = pygame.image.load(path.join(img_dir, "playerShip1_orange.png")).convert()
# meteor_img = pygame.image.load(path.join(img_dir, "meteorBrown_med1.png")).convert()
bullet_img = pygame.image.load(path.join(img_dir, "laserRed16.png")).convert()
enemy_img = pygame.image.load(path.join(img_dir, "enemyBlue1.png"))
energy_img = pygame.image.load(path.join(img_dir, "bold_silver.png"))
speed_img = pygame.image.load(path.join(img_dir, "star_gold.png"))
health_img = pygame.image.load(path.join(img_dir, "pill_red.png"))

# Загрузка всей игровой музыки и звуков
shoot_sound = pygame.mixer.Sound(path.join(snd_dir, "Laser_Shoot.wav"))
boost_sound = pygame.mixer.Sound(path.join(snd_dir, "boost.mp3"))
speed_sound = pygame.mixer.Sound(path.join(snd_dir, "speed.mp3"))
shoot_sound.set_volume(0.1)
boost_sound.set_volume(0.1)
speed_sound.set_volume(0.1)


expl_sounds = []
for snd in ["Explosion1.wav", "Explosion2.wav"]:
    expl_sounds.append(pygame.mixer.Sound(path.join(snd_dir, snd)))

for i in expl_sounds:
    i.set_volume(0.1)

pygame.mixer.music.load(path.join(snd_dir, "frozenjam-seamlessloop.ogg"))
pygame.mixer.music.set_volume(0.1)
pygame.mixer.music.play(loops=-1)

bullets = pygame.sprite.Group()
all_sprites = pygame.sprite.Group()
mobs = pygame.sprite.Group()
superbullets = pygame.sprite.Group()
player = Player()
all_sprites.add(player)
for i in range(3 * HARDMODE):
    m = Mob(player)
    all_sprites.add(m)
    mobs.add(m)
for i in range(1 * HARDMODE):
    m = Mob2(player)
    all_sprites.add(m)
    mobs.add(m)

timer = 0
ttimer = 0

# функции lose и win
def lose():
    pygame.mixer.music.stop()
    while True:
        # Устанавливаем значение ФПС
        clock.tick(FPS)
        # Проверка нажал ли игрок на крестик
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
                break
        screen.fill(RED)
        draw_text(x=(screen.get_width()//2), y=(screen.get_height()//2), text=f"ПОРАЖЕНИЕ! ИГРА ЗАКРОЕТСЯ ЧЕРЕЗ 3 СЕКУНДЫ! СЧЕТ: {score}")
        # ПОСЛЕ отрисовки всего, переворачиваем экран
        pygame.display.flip()
        time.sleep(3)
        break
def win():
    pygame.mixer.music.stop()
    while True:
        # Устанавливаем значение ФПС
        clock.tick(FPS)
        # Проверка нажал ли игрок на крестик
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
                break
        screen.fill(GREEN)
        draw_text(x=(screen.get_width()//2), y=(screen.get_height()//2), text="ПОБЕДА! ИГРА ЗАКРОЕТСЯ ЧЕРЕЗ 3 СЕКУНДЫ")
        # ПОСЛЕ отрисовки всего, переворачиваем экран
        pygame.display.flip()
        time.sleep(3)
        break

def mobSpawner():
    time.sleep(3)
    rand = randint(1, 10)
    if rand <= 8:
        bm = Mob(player)
        mobs.add(bm)
        all_sprites.add(bm)
    else:
        bm = Mob2(player)
        mobs.add(bm)
        all_sprites.add(bm)
pause = False

# Сама игра
while running:
    # Проверка столкновения мобов и пуль
    bm = pygame.sprite.groupcollide(mobs, bullets, True, True)
    for col in bm:
        random.choice(expl_sounds).play()
        Thread(target=mobSpawner).start()
        score += 1
        expl = Explosion(center=col.rect.center, size=col.type)
        all_sprites.add(expl)

    bm = pygame.sprite.groupcollide(mobs, superbullets, True, False)
    for col in bm:
        random.choice(expl_sounds).play()
        Thread(target=mobSpawner).start()
        score += 1
        expl = Explosion(center=col.rect.center, size=col.type)
        all_sprites.add(expl)

    # Прибавляем каждую секунду к таймеру значение 1
    if not pause:
        if ttimer != FPS:
            ttimer += 1
        if ttimer >= FPS:
            timer += 1
            ttimer = 0
        if pygame.time.get_ticks() % 1000 < 5:
            boost = Boost(player)
            all_sprites.add(boost)
        if timer % 20 == 0:
            player.bullets += 5
            timer += 1
        # Отсчет до конца игры
        if HARDMODE <= 2:
            if timer >= (150):
                running = False
                win()
        if HARDMODE > 2:
            if timer >= (180):
                running = False
                win()
    # Устанавливаем значение ФПС
    clock.tick(FPS)
    # Проверка нажал ли игрок на крестик
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
    keystate = pygame.key.get_pressed()
    if keystate[pygame.K_TAB]:
        pause = not pause
    # Обновление
    if not pause:
        all_sprites.update()
    if pause:
        pygame.mixer.music.pause()
    if not pause and not pygame.mixer.music.get_busy():
        pygame.mixer.music.unpause()
    screen.fill(BLACK)
    screen.blit(background, background_rect)
    all_sprites.draw(screen)
    draw_text(text=f"ОЧКИ: {score}", y=50, x=100)
    draw_text(text=f"{timer}СЕК", x=100, y=100)
    draw_text(text="Пауза - [TAB]", x=100, y=150)
    # draw_text(text=f"AMMO: {player.bullets}", x=100, y=200)
    # draw_text(text=f"{player.hp}HP", x=100, y=250)
    draw_shield_bar(screen, screen.get_width()-500, 5, player.hp, RED)
    draw_energy_bar(screen, screen.get_width()-500, 55, player.energy, BLUE)
    draw_ammo_bar(screen, screen.get_width()-500, 105, player.bullets, YELLOW)
    if player.hp < 26:
        draw_text(text="LOW HP", x=CENTER_X, y=CENTER_Y, color=RED, size=100)
    # ПОСЛЕ отрисовки всего, переворачиваем экран
    pygame.display.flip()

pygame.quit()